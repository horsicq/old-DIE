MinimizeAnimation demo
----------------------

This demo demonstrates the use of CoolTrayIcon's OnMinimizeToTray event, 
using animation effects.

The effects are provided as a proof of concept, and I'm well aware some of them 
(like the "Implode outline" effect) have bugs.

If you find a way to improve the effects or even develop new ones, send your 
code to me, and I'll include it in future versions of CoolTrayIcon.

If you feel like including similar animation effects in your application,
remember the simple guideline for good design: Less is more. Animation effects
are most often useless, and some people tend to get annoyed at them in the
long run. Use animation and sound sparingly. Windows is bad enough as it is.

